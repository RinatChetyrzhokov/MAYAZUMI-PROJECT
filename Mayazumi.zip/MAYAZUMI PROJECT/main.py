import disnake
from disnake.ext import commands

bot = commands.Bot(command_prefix="!", intents=disnake.Intents.all(), activity=disnake.Streaming(name='MAYAZUMI community', url='https://www.twitch.tv/mayazumi', status=disnake.Status.online))

bot.remove_command('help')

bot.load_extension("cogs.shop")
bot.load_extension("cogs.balance")
bot.load_extension("cogs.reward")
bot.load_extension("cogs.verify")
bot.load_extension("cogs.events")
bot.load_extension("cogs.moderation")
bot.load_extension("cogs.VoiceChannels")
bot.load_extension("cogs.Transfer")
bot.load_extension("cogs.banner")
bot.load_extension("cogs.AutoRole")

@bot.event
async def on_ready():
     print("Бот готов")
     print(disnake.__version__)

token = open('token.txt', 'r').readline()
bot.run(token)