import disnake
from disnake.ext import commands
import sqlite3
import disnake.utils

class Event(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.db = sqlite3.connect("my_database.db")
        self.db.execute("CREATE TABLE IF NOT EXISTS server_settings (server_id INTEGER PRIMARY KEY, role_id INTEGER, category_id INTEGER)")

    async def create_event_channel(self, name, role, category):
        guild = self.client.get_guild(1007361673813823548)  # замените на id сервера
        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(view_channel=False),
            guild.me: disnake.PermissionOverwrite(view_channel=True),
            role: disnake.PermissionOverwrite(view_channel=True)
        }
        await category.guild.create_voice_channel(name, category=category, overwrites=overwrites)

    @commands.slash_command()
    async def set_event_role(self, ctx, role: disnake.Role):
        self.role = role
        await ctx.send(f"Роль для создания ивентов установлена: {role.mention}", ephemeral=True)

    @commands.slash_command()
    async def set_event_category(self, ctx, category: disnake.CategoryChannel):
        self.category = category
        self.db.execute("INSERT OR REPLACE INTO server_settings (server_id, category_id) VALUES (?, ?)", (ctx.guild.id, category.id))
        self.db.commit()
        await ctx.response.send_message(f"Категория для создания ивентов установлена: {category.mention}", ephemeral=True)

    @commands.slash_command()
    async def event_create(self, ctx, name: str):
        if not hasattr(self, "role") or not hasattr(self, "category"):
            await ctx.send("Роль или категория для создания ивентов не установлены.", ephemeral=True)
            return

        await self.create_event_channel(name, self.role, self.category)
        await ctx.send(f"Создан канал для эвента '{name}'", ephemeral=True)

    @commands.slash_command()
    async def event_close(self, ctx):
        channel = ctx.channel
        if isinstance(channel, disnake.TextChannel):
            await channel.delete()
            await ctx.send("Канал эвента удален", ephemeral=True)
        else:
            await ctx.send("Команду можно использовать только в текстовых каналах", ephemeral=True)

    @commands.has_role(1007550724432994325)
    @commands.slash_command()
    async def event_reward(self, ctx, event_name: str, count: int, participants: str):
        if event_name.lower() == "бункер":
            reward = 60
        elif event_name.lower() == "gartic phone":
            reward = 50
        elif event_name.lower() == "коднеймс":
            reward = 50
        elif event_name.lower() == "монополия":
            reward = 60
        elif event_name.lower() == "мафия":
            reward = 120
        elif event_name.lower() == "дурак онлайн":
            reward = 40
        elif event_name.lower() == "шляпа":
            reward = 70
        elif event_name.lower() == "пазлы":
            reward = 15
        elif event_name.lower() == "alias":
            reward = 40
        elif event_name.lower() == "jackbox":
            reward = 35
        else:
            await ctx.send("Неизвестный эвент", ephemeral=True)
            return

        participants_list = participants.split(",")
        participants_count = len(participants_list)

        for participant in participants_list:
            try:
                user_id = int(participant)
                user = disnake.utils.get(ctx.guild.members, id=user_id)
                if user is None:
                    raise ValueError(f"Пользователь с ID {user_id} не найден.")
                self.db.execute(f"UPDATE users SET balance = balance + ? WHERE user_id = ?", (reward * count, user.id))
                self.db.commit()
            except (ValueError, IndexError) as e:
                await ctx.send(f"Ошибка: {e}. Строка '{participant}' будет пропущена.", ephemeral=True)
                continue

        await ctx.send(f"Участников: {participants_count}. Всем было начислено по {reward * count} 🔋.", ephemeral=True)

def setup(client):
    client.add_cog(Event(client))