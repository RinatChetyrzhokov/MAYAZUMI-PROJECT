import disnake
from disnake.ext import commands
import sqlite3

class Shop(commands.Cog):
    def __init__(self, bot, conn):
        self.bot = bot
        self.conn = conn
        self.cur = conn.cursor()
        self.cur.execute('CREATE TABLE IF NOT EXISTS roles (name TEXT PRIMARY KEY, price INT)')
        self.cur.execute('CREATE TABLE IF NOT EXISTS roles_bought (user_id INT, role_name TEXT, FOREIGN KEY(user_id) REFERENCES users(user_id));')
            

    async def show_page(self, ctx, page):
        roles = self.get_roles(ctx, page)
        embed = disnake.Embed(color=0x000000, title="Магазин ролей")
        for role in roles:
            embed.add_field(name=role[0], value=f"Цена: {role[1]} 🔋", inline=False)

        if page > 1:
            embed.set_footer(text="Нажмите ◀️ для предыдущей страницы")
        if len(roles) == 5:
            embed.set_footer(text="Нажмите ▶️ для следующей страницы")

        msg = await ctx.channel.send(embed=embed)

        if page > 1:
            await msg.add_reaction("◀️")
        if len(roles) == 5:
            await msg.add_reaction("▶️")

        await msg.add_reaction("🛒")
        await msg.add_reaction("🆕")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["🛒", "🆕", "◀️", "▶️"]

        reaction, user = await self.bot.wait_for("reaction_add", check=check)

        if str(reaction.emoji) == "🛒":
            await msg.clear_reactions()
            await self.buy_role(ctx)
        elif str(reaction.emoji) == "🆕":
            await msg.clear_reactions()
            await self.create_role(ctx)
        elif str(reaction.emoji) == "◀️":
            await msg.delete()
            await self.show_page(ctx, page - 1)
        elif str(reaction.emoji) == "▶️":
            await msg.delete()
            await self.show_page(ctx, page + 1)

    def get_roles(self, ctx, page):
        self.cur.execute(f"SELECT name, price FROM roles LIMIT {page * 5 - 5}, 5")
        roles = self.cur.fetchall()
        guild_roles = [(role.name, 0) for role in ctx.guild.roles if not role.managed and role.name.startswith('Роль ')]
        return roles + guild_roles

    async def buy_role(self, ctx):
        embed = disnake.Embed(color=0x000000, title="Выберите роль для покупки")
        roles = self.get_roles(ctx, 1)  # получаем все доступные роли
        for i, role in enumerate(roles):
            embed.add_field(name=f"{i + 1}️⃣ {role[0]}", value=f"Цена: {role[1]} 🔋")

        msg = await ctx.channel.send(embed=embed)

        emojis = [f"{i + 1}️⃣" for i in range(len(roles))]
        for emoji in emojis:
            await msg.add_reaction(emoji)

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in emojis

        reaction, user = await self.bot.wait_for("reaction_add", check=check)

        role_price = roles[emojis.index(str(reaction.emoji))][1]
        role_name = roles[emojis.index(str(reaction.emoji))][0]
        user_id = ctx.author.id

        self.cur.execute(f"SELECT balance FROM users WHERE user_id={user_id}")
        user_balance = self.cur.fetchone()[0]

        if user_balance < role_price:
            await ctx.channel.send("У вас недостаточно 🔋 для покупки этой роли.")
        else:

            self.cur.execute(f"UPDATE users SET balance={user_balance - role_price} WHERE user_id={user_id}")
            self.cur.execute(f"INSERT INTO roles_bought (user_id, role_name) VALUES ({user_id}, ?)", (role_name,))

            role = disnake.utils.get(ctx.guild.roles, name=role_name)
            await ctx.author.add_roles(role)
            await ctx.channel.send(f"Вы успешно купили {role_name} за {role_price} 🔋.")

        self.conn.commit()

    @commands.slash_command(name="shop", description="Магазин ролей")
    async def shop(self, ctx):
        page = 1
        await self.show_page(ctx, page)

    async def create_role(self, ctx):
        # Получение информации о пользователе, создающем роль
        author_id = str(ctx.author.id)
        self.cur.execute("SELECT balance FROM users WHERE user_id = ?", (author_id,))
        result = self.cur.fetchone()
        if not result:  # Если пользователь не найден в базе данных
            await ctx.channel.send("Произошла ошибка при получении информации о пользователе.")
            return

        # Получение и проверка данных пользовательской роли
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        await ctx.channel.send("Введите название вашей роли")
        msg = await self.bot.wait_for('message', check=check)
        role_name = msg.content

        await ctx.channel.send("Укажите её стоимость для покупателей (🔋 - батарейки)")
        msg = await self.bot.wait_for('message', check=check)
        try:
            role_price = int(msg.content)
        except ValueError:
            await ctx.channel.send("Цена должна быть числом!")
            return

        # Проверка баланса пользователя
        user_balance = result[0]  # Получение баланса пользователя из результата запроса
        if user_balance < 7000:
            await ctx.channel.send("У вас недостаточно 🔋 для создания роли.")
            return

        # Создание роли и добавление в базу данных
        guild = ctx.guild
        new_role = await guild.create_role(name=role_name)

        await ctx.author.add_roles(new_role)

        # Обновление базы данных
        self.cur.execute("INSERT INTO roles(name, price) VALUES (?, ?)", (new_role.name, role_price))
        self.cur.execute("UPDATE users SET balance = balance - 7000 WHERE user_id = ?", (author_id,))
        self.conn.commit()

        await ctx.channel.send(f"Роль '{new_role.name}' успешно создана и добавлена в магазин!")


def setup(bot):
    conn = sqlite3.connect('my_database.db')
    bot.add_cog(Shop(bot, conn))