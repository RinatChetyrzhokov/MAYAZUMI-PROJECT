import disnake
from disnake import guild, Member, VoiceState, CategoryChannel, Permissions
from disnake.ext import commands

join_channel_id = 1112396216383316038
category_channel_id = 1112379601847595060

class VoiceChannels(commands.Cog):
  def __init__(self, bot):
    self.bot = bot

  @commands.Cog.listener()
  async def on_voice_state_update(self, member: Member, old_state: VoiceState, new_state: VoiceState):
    guild: Guild = member.guild
    
    # Проверяем, произошло ли событие присоединения к каналу
    if new_state.channel and new_state.channel.id == join_channel_id:
      try:
        # Создаем новый голосовой канал
        category_channel: CategoryChannel = guild.get_channel(category_channel_id)
        created_channel: disnake.VoiceChannel = await category_channel.create_voice_channel(f"{member.display_name}'s channel")

        # Перемещаем участника в новый канал
        await member.move_to(created_channel)

        # Предоставляем права на чтение и запись только для гостя канала
        await created_channel.set_permissions(member, overwrite=Permissions.all())

        print(f"Voice channel {created_channel.name} created for {member.display_name}")
      except Exception as err:
        print(f"Failed to create voice channel for {member.display_name}: {err}")
    else:
      try:
        # Получаем список всех голосовых каналов в категории и удаляем пустые каналы
        category_channels = [channel for channel in guild.voice_channels if channel.category_id == category_channel_id]
        empty_channels = [channel for channel in category_channels if not channel.members and channel.id != join_channel_id]

        for channel in empty_channels:
          await channel.delete()
          print(f"Voice channel {channel.name} deleted due to inactivity")
      except Exception as err:
        print(f"Failed to delete inactive voice channels: {err}")

def setup(bot):
    bot.add_cog(VoiceChannels(bot))