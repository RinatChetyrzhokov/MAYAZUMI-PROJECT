import disnake
from disnake.ext import commands
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import asyncio

class Banner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.banner_images = {123456789: 'banner1.png', 987654321: 'banner2.png'}  # пример картинок баннеров на разных серверах
        self.text_locations = {123456789: (250, 660), 987654321: (400, 200)}  # примеры местоположений текста на разных серверах
        self.banner_task = self.bot.loop.create_task(self.update_banner())

    async def update_banner(self):
        await self.bot.wait_until_ready()
        while True:
            for server_id, banner_image_path in self.banner_images.items():
                server = self.bot.get_guild(server_id)
                members = server.member_count
                image = self.create_banner(server, banner_image_path, members)  # генерируем новый баннер
                await server.edit(banner=image)  # загружаем новый баннер на сервер
            await asyncio.sleep(5)  # обновляем каждый час

    @staticmethod
    def create_banner(server, banner_image_path, members):
        banner = Image.open(banner_image_path)
        font = ImageFont.truetype('times.ttf', 80)
        draw = ImageDraw.Draw(banner)
        draw.text(self.text_locations[server.id], f'{members}', fill=(255, 255, 255), font=font)
        image_bytes = BytesIO()
        banner.save(image_bytes, format='PNG')
        image_bytes.seek(0)
        return image_bytes.getvalue()

    @commands.command()
    async def updatebanner(self, ctx):
        server = ctx.guild
        members = server.member_count
        image = self.create_banner(server, self.banner_images[server.id], members)
        await server.edit(banner=image)
        await ctx.send('Баннер успешно обновлен!')

def setup(bot):
    bot.add_cog(Banner(bot))