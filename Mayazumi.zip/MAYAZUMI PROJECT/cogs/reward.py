import disnake
from disnake.ext import commands, tasks
import sqlite3
import datetime
import pytz

class Reward(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.conn = sqlite3.connect('my_database.db')
        self.db = self.conn.cursor()
        self.db.execute('CREATE TABLE IF NOT EXISTS users (balance INTEGER DEFAULT 50, user_id INTEGER PRIMARY KEY, last_reward TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
        self.last_rewards = {}

        self.reward_loop.start()

    @tasks.loop(hours=2)
    async def reward_loop(self):
        now = datetime.datetime.now(pytz.utc)
        self.db.execute("SELECT user_id FROM users WHERE last_reward <= ?", [(now - datetime.timedelta(hours=2)).isoformat()])
        rows = self.db.fetchall()
        for row in rows:
            user_id = row[0]
            self.db.execute("UPDATE users SET balance = balance + 200, last_reward = ? WHERE user_id=?", (now.isoformat(), user_id))
            self.last_rewards[user_id] = now
        self.conn.commit()

    @commands.slash_command(
        name="reward",
        description="Получить награду в размере 200 энергетических батареек"
    )
    async def _reward(self, ctx: disnake.ApplicationCommandInteraction):
        user = ctx.author
        user_id = user.id

        self.db.execute("SELECT last_reward, balance FROM users WHERE user_id = ?", (user_id,))
        row = self.db.fetchone()
        if not row:
            await ctx.send(f"{user.mention}, у вас нет банковского счёта! Откройте его с помощью команды /balance.")
            return

        last_reward, balance = row
        now = datetime.datetime.now(pytz.utc)

        if user_id in self.last_rewards:
            last_reward = self.last_rewards[user_id]
        elif last_reward is not None:
            last_reward = datetime.datetime.fromisoformat(last_reward).astimezone(pytz.utc)

        if last_reward is not None and (now - last_reward).total_seconds() < 60 * 60 * 2:
            # Если пользователь уже получал награду менее 2 часов назад
            remaining_time = (last_reward + datetime.timedelta(hours=2) - now).seconds // 60
            await ctx.send(f"{user.mention}, вы уже получали 🔋 за последние 2 часа. Пожалуйста, подождите ещё {remaining_time} минут.")
            return

        self.db.execute("UPDATE users SET balance = balance + 200, last_reward = ? WHERE user_id=?", (now.isoformat(), user_id,))
        self.last_rewards[user_id] = now
        self.conn.commit()

        new_balance = balance + 200
        balance_embed = disnake.Embed(
            color=0x000000,
            title=f"Reward for {user}",
            description=f"{user.mention}, вы получили 200 🔋! Ваш текущий баланс: {new_balance}."
        )
        await ctx.send(embed=balance_embed)

def setup(bot):
    bot.add_cog(Reward(bot))