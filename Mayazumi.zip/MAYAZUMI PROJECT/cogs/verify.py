from disnake.ext import commands
from disnake import Member, Role, Embed
from typing import Optional

class Verification(commands.Cog):
    def init(self, bot):
        self.bot = bot

    @commands.slash_command(name="verify", description="Верификация/ не допуск пользователей на сервере")
    @commands.has_role(1007550395838631996)
    async def verify(self, inter, member: Member, role: Optional[Role]):
        if role is None:
            return await inter.response.send_message("Пожалуйста укажите роль для верификации.", ephemeral=True)
        elif role.id == 1111625903286530058:
            await member.add_roles(role)
            await member.remove_roles(inter.guild.get_role(1111940890571853924))
            return await inter.response.send_message(f"{member.mention} был не допущен на сервер и ему была выдана соответствующая роль.", ephemeral=True)
        elif role.id not in [1007628548682559499, 1007628632874823793]:
            return await inter.response.send_message("Эта роль не может быть выдана, роли для верификации/не допуска: <@&1007628548682559499>, <@&1007628632874823793>, <@&1111625903286530058>", ephemeral=True)
        else:
            await member.add_roles(role)
            await member.remove_roles(inter.guild.get_role(1111940890571853924))
            embed = Embed(title="Verification successful!", description=f"{member.mention} роль {role.name} выдана.", color=0x000000)
            await inter.response.send_message(embed=embed, ephemeral=True)

    @verify.error
    async def verify_error(self, inter, error):
        if isinstance(error, commands.MissingRole):
            await inter.response.send_message("У вас нет необходимой роли для использования этой команды.", ephemeral=True)

def setup(bot):
    bot.add_cog(Verification(bot))