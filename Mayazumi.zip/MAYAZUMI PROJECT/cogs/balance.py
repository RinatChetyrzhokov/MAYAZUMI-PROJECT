import disnake
from disnake.ext import commands
import sqlite3

class BalanceCog(commands.Cog):
    def __init__(self, bot, conn):
        self.bot = bot
        self.conn = conn
        self.db = conn.cursor()
        self.db.execute('CREATE TABLE IF NOT EXISTS users (balance INTEGER DEFAULT 50, user_id INTEGER PRIMARY KEY, last_reward TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)')

    @commands.slash_command(
        name="balance",
        description="Ваш банковский счёт"
    )
    async def _balance(self, ctx: disnake.ApplicationCommandInteraction):
        user = ctx.author
        user_id = user.id

        self.db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
        user_balance = self.db.fetchone()

        if user_balance is None:
            self.db.execute("INSERT INTO users(user_id) VALUES(?)", (user_id,))
            self.conn.commit()  # изменено на self.conn.commit()
            await ctx.send(f"{user.mention}, Вы только что открыли свой банковский счёт! На нём уже есть 50 🔋.")
        else:
            balance_embed = disnake.Embed(
                color=0x000000,
                title=f"{user}"
            )
            balance_embed.add_field(name="🔋-Батареек", value=user_balance[0])
            await ctx.send(embed=balance_embed)

    @commands.slash_command(
        name="reset_balance",
        description="Сбросить баланс пользователя до 0"
    )
    @commands.has_permissions(administrator=True)
    async def _reset_balance(self, ctx: disnake.ApplicationCommandInteraction, user: disnake.Member):
        self.db.execute("UPDATE users SET balance = 0 WHERE user_id=?", (user.id,))
        self.conn.commit()
        await ctx.send(f"{user.mention} баланс был обнулен.")

def setup(bot):
    conn = sqlite3.connect('my_database.db')
    bot.add_cog(BalanceCog(bot, conn))