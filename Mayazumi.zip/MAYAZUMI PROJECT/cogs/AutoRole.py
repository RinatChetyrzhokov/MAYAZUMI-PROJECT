import disnake
from disnake.ext import commands
import sqlite3

class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        connection = sqlite3.Connection("autosettings.db")
        cursor = connection.cursor()

        # Create the table if it doesn't exist
        cursor.execute("CREATE TABLE IF NOT EXISTS auto_settings (guild_id INT PRIMARY KEY, role_id INT)")

        # Get auto role settings for the guild
        guild_id = member.guild.id
        cursor.execute("SELECT role_id FROM auto_settings WHERE guild_id = ?", (guild_id,))
        result = cursor.fetchone()

        if result is not None:
            role_id = result[0]
            role = member.guild.get_role(role_id)
            if role is not None:
                await member.add_roles(role)

        connection.commit()
        cursor.close()
        connection.close()

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def set_autorole(self, ctx: commands.Context, role: disnake.Role):
        connection = sqlite3.Connection("autosettings.db")
        cursor = connection.cursor()

        # Create the table if it doesn't exist
        cursor.execute("CREATE TABLE IF NOT EXISTS auto_settings (guild_id INT PRIMARY KEY, role_id INT)")

        # Insert or update the auto role settings for the guild
        guild_id = ctx.guild.id
        cursor.execute("INSERT INTO auto_settings (guild_id, role_id) VALUES (?, ?) "
                       "ON CONFLICT(guild_id) DO UPDATE SET role_id = ?",
                       (guild_id, role.id, role.id))

        connection.commit()
        cursor.close()
        connection.close()

        await ctx.send("Auto role settings have been updated.")

def setup(bot):
    bot.add_cog(AutoRole(bot))