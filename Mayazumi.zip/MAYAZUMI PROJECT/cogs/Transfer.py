import disnake
from disnake.ext import commands
import sqlite3

class Transfer(commands.Cog):
    def __init__(self, bot, conn):
        self.conn = conn
        self.db = conn.cursor()
        self.db.execute('CREATE TABLE IF NOT EXISTS users (balance INTEGER DEFAULT 50, user_id INTEGER PRIMARY KEY, last_reward TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)')

    @commands.slash_command(
        name="transfer",
        description="Переводит энергетические батарейки другому пользователю."
    )
    async def _transfer(self, ctx: disnake.ApplicationCommandInteraction, user: disnake.User, amount: int):
        if amount <= 0:
            await ctx.send("Количество батареек должно быть больше нуля.")
            return

        sender_id = ctx.author.id
        receiver_id = user.id

        if sender_id == receiver_id:
            await ctx.send("Нельзя отправить батарейки самому себе.")
            return

        self.db.execute("SELECT balance FROM users WHERE user_id=?", (sender_id,))
        sender_balance = self.db.fetchone()

        if sender_balance is None:
            await ctx.send("Вы еще не открыли свой банковский счет.")
            return
        elif sender_balance[0] < amount:
            await ctx.send("У вас недостаточно батареек.")
            return

        self.db.execute("SELECT balance FROM users WHERE user_id=?", (receiver_id,))
        receiver_balance = self.db.fetchone()

        if receiver_balance is None:
            self.db.execute("INSERT INTO users(user_id, balance) VALUES(?,?)", (receiver_id, amount))
        else:
            new_balance = receiver_balance[0] + amount
            self.db.execute("UPDATE users SET balance=? WHERE user_id=?", (new_balance, receiver_id))

        new_balance = sender_balance[0] - amount
        self.db.execute("UPDATE users SET balance=? WHERE user_id=?", (new_balance, sender_id))
        self.conn.commit()  # изменено на self.conn.commit()

        sender_name = ctx.author.display_name
        receiver_name = user.display_name
        success_embed = disnake.Embed(
            title="Успешный перевод",
            description=f"{sender_name} отправил {amount} 🔋 на счет {receiver_name}."
        )
        await ctx.send(embed=success_embed)

def setup(bot):
    conn = sqlite3.connect('my_database.db')
    bot.add_cog(Transfer(bot, conn))