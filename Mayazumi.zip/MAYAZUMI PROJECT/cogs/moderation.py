import discord
from discord.ext import commands
import disnake
from disnake.ext import commands
import asyncio

class ModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.slash_command(name='mute', description="Забирает право писать у пользователя, на определённое время")
    async def mute_user(self, ctx, member: disnake.Member, timeout: int):
        if ctx.author.id != 1007550271846629417 and not ctx.author.guild_permissions.administrator:
            return await ctx.respond(f"У вас нет доступа к этой команде.")
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            muted_role = await ctx.guild.create_role(name="Muted", permissions=discord.Permissions(send_messages=False))
            for channel in ctx.guild.channels:
                await channel.set_permissions(muted_role, send_messages=False)
        await member.add_roles(muted_role)
        await ctx.respond(f"{member.mention} замучен в текстовых каналах на {timeout} секунд.")
        await asyncio.sleep(timeout)
        await member.remove_roles(muted_role)
        await ctx.followup(f"{member.mention} размучен в текстовых каналах")
    
    @commands.slash_command(name='unmute', description="Даёт право говорить пользователю")
    async def unmute_user(self, ctx, member: disnake.Member):
        if ctx.author.id != 1007550271846629417 and not ctx.author.guild_permissions.administrator:
            return await ctx.respond(f"У вас нет доступа к этой команде.")
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if muted_role in member.roles:
            await member.remove_roles(muted_role)
            await ctx.respond(f"{member.mention} размучен в текстовых каналах")
        else:
            await ctx.respond(f"{member.mention} не замучен в текстовых каналах")

    @commands.slash_command(name='warning', description="Выдаёт предупреждение пользователю")
    async def warning_user(self, ctx, member: disnake.Member, reason: str):
        if ctx.author.id != 1007550271846629417 and not ctx.author.guild_permissions.administrator:
            return await ctx.respond(f"У вас нет доступа к этой команде.")
        warn_channel = discord.utils.get(ctx.guild.channels, name="warn-logs")
        if not warn_channel:
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                ctx.guild.me: discord.PermissionOverwrite(read_messages=True)
            }
            warn_channel = await ctx.guild.create_text_channel(name="warn-logs", overwrites=overwrites)
            embed = discord.Embed(title="Предупреждение", description=f"Пользователь: {member.mention}\n**Модератор: {ctx.author.mention}\n**Причина: {reason}")
        await warn_channel.send(embed=embed)
        await ctx.respond(f"{member.mention} получил предупреждение.")
    
    @commands.slash_command(name='clear', description="Очищает все сообщения пользователя в чате" )
    async def clear_messages(self, ctx, member: disnake.Member):
        if ctx.author.id != 1113521321591177286 and not ctx.author.guild_permissions.administrator:
            return await ctx.respond(f"У вас нет доступа к этой команде.")
        await ctx.channel.purge(limit=100, check=lambda msg: msg.author.id == member.id)
    
    @commands.slash_command(name='vmute', description="Забирает право говорить у пользователя, на определённое время")
    async def mute_user_vc(self, ctx, member: disnake.Member, timeout: int):
        if ctx.author.id != 1007550271846629417 and not ctx.author.guild_permissions.administrator:
            return await ctx.respond(f"У вас нет доступа к этой команде.")
        await member.edit(mute=True)
        await asyncio.sleep(timeout)
        await member.edit(mute=False)
        await ctx.respond(f"{member.mention} замучен в голосовых каналах на {timeout} секунд.")

def setup(bot):
    bot.add_cog(ModerationCog(bot))